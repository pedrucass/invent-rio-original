-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
vRPS = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
local vGARAGE = Tunnel.getInterface("garages")
vSERVER = Tunnel.getInterface(GetCurrentResourceName())
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
local Humble = {}
Tunnel.bindInterface(GetCurrentResourceName(), Humble)
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local CurrentInventory = {}
local CurrentWeapon = ""
local dropList = {}
local UseCooldown = GetGameTimer()
local Usables = 1
local defaultTimeout = 60000
local StoreWeapon = false
local TakeWeapon = false
local Drops = {}
local fireTimers
local firecracker
local uCarry
local iCarry = false
local sCarry = false
local Types = ""
local scaleForms = {}
local useWeapon = ""
local putWeaponHands = false
local storeWeaponHands = false
local timeReload = GetGameTimer()
local plyIdentity = {}
local plyInventory = {}
local WEAPON_UNARMED = "WEAPON_UNARMED"
local useItemCooldown = 0
local blockButtons = false
local Paralyzing = false
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CANCEL
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:Cancel")
AddEventHandler("inventory:Cancel",function()
	vSERVER.Cancel()
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:VERIFYOBJECTS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:VerifyObjects")
AddEventHandler("inventory:VerifyObjects",function(Entity,Service)
	vSERVER.VerifyObjects(Entity,Service)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:LOOT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:Loot")
AddEventHandler("inventory:Loot",function(Entity,Service)
	vSERVER.Loot(Entity,Service)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:STEALTRUNK
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:StealTrunk")
AddEventHandler("inventory:StealTrunk",function(Entity)
	vSERVER.StealTrunk(Entity)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:ANIMALS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:Animals")
AddEventHandler("inventory:Animals",function(Entity,Service)
	vSERVER.Animals(Entity,Service)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:STOREOBJECTS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:StoreObjects")
AddEventHandler("inventory:StoreObjects",function(Number)
	vSERVER.StoreObjects(Number)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:REMOVETYRES
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:RemoveTyres")
AddEventHandler("inventory:RemoveTyres",function(Entity)
	vSERVER.RemoveTyres(Entity)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTS:WEAPONS
-----------------------------------------------------------------------------------------------------------------------------------------
exports("Weapons",function()
	return Weapon
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- WEAPONSAMMOS
-----------------------------------------------------------------------------------------------------------------------------------------
local weaponAmmos = {
	["WEAPON_PISTOL_AMMO"] = {
		"WEAPON_PISTOL",
		"WEAPON_PISTOL_MK2",
		"WEAPON_PISTOL50",
		"WEAPON_REVOLVER",
		"WEAPON_COMBATPISTOL",
		"WEAPON_APPISTOL",
		"WEAPON_HEAVYPISTOL",
		"WEAPON_SNSPISTOL",
		"WEAPON_SNSPISTOL_MK2",
		"WEAPON_VINTAGEPISTOL"
	},
	["WEAPON_NAIL_AMMO"] = {
		"WEAPON_NAILGUN"
	},
	["WEAPON_RPG_AMMO"] = {
		"WEAPON_RPG"
	},
	["WEAPON_SMG_AMMO"] = {
		"WEAPON_MICROSMG",
		"WEAPON_MINISMG",
		"WEAPON_SMG",
		"WEAPON_SMG_MK2",
		"WEAPON_GUSENBERG",
		"WEAPON_MACHINEPISTOL",
		"WEAPON_ASSAULTSMG",
		"WEAPON_COMPACTRIFLE"
	},
	["WEAPON_RIFLE_AMMO"] = {
		"WEAPON_FNFAL",
		"WEAPON_PARAFAL",
		"WEAPON_COLTXM177",
		"WEAPON_CARBINERIFLE",
		"WEAPON_CARBINERIFLE_MK2",
		"WEAPON_BULLPUPRIFLE",
		"WEAPON_BULLPUPRIFLE_MK2",
		"WEAPON_ADVANCEDRIFLE",
		"WEAPON_TACTICALRIFLE",
		"WEAPON_ASSAULTRIFLE",
		"WEAPON_HEAVYRIFLE",
		"WEAPON_ASSAULTRIFLE_MK2",
		"WEAPON_SPECIALCARBINE",
		"WEAPON_SPECIALCARBINE_MK2"
	},
	["WEAPON_SHOTGUN_AMMO"] = {
		"WEAPON_PUMPSHOTGUN",
		"WEAPON_PUMPSHOTGUN_MK2",
		"WEAPON_SAWNOFFSHOTGUN"
	},
	["WEAPON_MUSKET_AMMO"] = {
		"WEAPON_MUSKET",
		"WEAPON_SAUER"
	},
	["WEAPON_PETROLCAN_AMMO"] = {
		"WEAPON_PETROLCAN"
	}
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- REPAIRENGINE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:repairEngine")
AddEventHandler("inventory:repairEngine",function(Index,Plate)
	if NetworkDoesNetworkIdExist(Index) then
		local Vehicle = NetToEnt(Index)
		if DoesEntityExist(Vehicle) then
			if GetVehicleNumberPlateText(Vehicle) == Plate then
				local Tyres = {}

				for i = 0,7 do
					local Status = false

					if GetTyreHealth(Vehicle,i) ~= 1000.0 then
						Status = true
					end

					Tyres[i] = Status
				end

				local Fuel = GetVehicleFuelLevel(Vehicle)

				SetVehicleEngineHealth(Vehicle,1000.0)
				SetVehiclePetrolTankHealth(Vehicle,1000.0)

				SetVehicleFuelLevel(Vehicle,Fuel)

				for Tyre,Burst in pairs(Tyres) do
					if Burst then
						SetVehicleTyreBurst(Vehicle,Tyre,true,1000.0)
					end
				end
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- REPAIRVEHICLE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:repairVehicle")
AddEventHandler("inventory:repairVehicle",function(Index,Plate)
	if NetworkDoesNetworkIdExist(Index) then
		local Vehicle = NetToEnt(Index)
		if DoesEntityExist(Vehicle) then
			if GetVehicleNumberPlateText(Vehicle) == Plate then
				local vehTyres = {}

				for i = 0,7 do
					local Status = false

					if GetTyreHealth(Vehicle,i) ~= 1000.0 then
						Status = true
					end

					vehTyres[i] = Status
				end

				local Fuel = GetVehicleFuelLevel(Vehicle)

				SetVehicleFixed(Vehicle)
				SetVehicleDeformationFixed(Vehicle)

				SetVehicleFuelLevel(Vehicle,Fuel)

				for Tyre,Burst in pairs(vehTyres) do
					if Burst then
						SetVehicleTyreBurst(Vehicle,Tyre,true,1000.0)
					end
				end
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:REPAIRTYRE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:repairTyre")
AddEventHandler("inventory:repairTyre",function(Vehicle,Tyres,Plate)
	if NetworkDoesNetworkIdExist(Vehicle) then
		local Vehicle = NetToEnt(Vehicle)
		if DoesEntityExist(Vehicle) then
			if GetVehicleNumberPlateText(Vehicle) == Plate then
				for i = 0,7 do
					if GetTyreHealth(Vehicle,i) ~= 1000.0 then
						SetVehicleTyreBurst(Vehicle,i,true,1000.0)
					end
				end

				SetVehicleTyreFixed(Vehicle,Tyres)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- REPAIRPLAYER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:repairPlayer")
AddEventHandler("inventory:repairPlayer",function(Index,Plate)
	if NetworkDoesNetworkIdExist(Index) then
		local Vehicle = NetToEnt(Index)
		if DoesEntityExist(Vehicle) then
			if GetVehicleNumberPlateText(Vehicle) == Plate then
				SetVehicleEngineHealth(Vehicle,1000.0)
				SetVehicleBodyHealth(Vehicle,1000.0)
				SetEntityHealth(Vehicle,1000)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- REPAIRADMIN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:repairAdmin")
AddEventHandler("inventory:repairAdmin",function(Index,Plate)
	if NetworkDoesNetworkIdExist(Index) then
		local Vehicle = NetToEnt(Index)
		if DoesEntityExist(Vehicle) then
			if GetVehicleNumberPlateText(Vehicle) == Plate then
				local Fuel = GetVehicleFuelLevel(Vehicle)

				SetVehicleFixed(Vehicle)
				SetVehicleDeformationFixed(Vehicle)

				SetVehicleFuelLevel(Vehicle,Fuel)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- LOADNAMEASSET
-----------------------------------------------------------------------------------------------------------------------------------------
function LoadNamedPtfxAsset(asset, timeout)
    if not HasNamedPtfxAssetLoaded(asset) then
        RequestNamedPtfxAsset(asset)
        while not HasNamedPtfxAssetLoaded(asset) do Wait(50) end
        SetTimeout(timeout or defaultTimeout, function() RemoveNamedPtfxAsset(asset) end)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- ERRORINVENTORY
-----------------------------------------------------------------------------------------------------------------------------------------
local function errorSound()
    PlaySound(-1, "CHECKPOINT_MISSED", "HUD_MINI_GAME_SOUNDSET", false, false, false)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- GENERATEPROFILE
-----------------------------------------------------------------------------------------------------------------------------------------
local function generateProfilePicture()
    local mugshot = RegisterPedheadshotTransparent(PlayerPedId())
    while not IsPedheadshotReady(mugshot) do
        Wait(100)
    end
    SendNUIMessage { action = "generateMugshot", payload = GetPedheadshotTxdString(mugshot) }
    SetTimeout(1500, function()
        UnregisterPedheadshot(mugshot)
    end)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DROPLIST
-----------------------------------------------------------------------------------------------------------------------------------------
local function GetDropList()
    local Items = {}

    local Ped = PlayerPedId()
    local Coords = GetEntityCoords(Ped)
    local _, CoordsZ = GetGroundZFor_3dCoord(Coords["x"], Coords["y"], Coords["z"])

    for Index, v in pairs(Drops) do
        if #(vec3(Coords["x"], Coords["y"], CoordsZ) - vec3(v["Coords"][1], v["Coords"][2], v["Coords"][3])) <= 0.9 then
            local Number = #Items + 1

            Items[Number] = v
            Items[Number]["id"] = Index
        end
    end

    return Items
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DROPDATA
-----------------------------------------------------------------------------------------------------------------------------------------
local function SetDropData()
    local Ped = PlayerPedId()
    local groundDropList = GetDropList()
    if table.type(groundDropList) == "empty" then return end
    SendNUIMessage({
        action = "setOtherInventory",
        payload = {
            title = "Chão",
            inventory = groundDropList,
            slots = 90
        }
    })
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- OPEN:BOLSA
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand("moc", function()
    local Ped = PlayerPedId()
    if GetEntityHealth(Ped) < 102 then return end
    if not LocalPlayer["state"]["Commands"] and not LocalPlayer["state"]["Handcuff"] and not IsPauseMenuActive() then
        if IsPlayerFreeAiming(128) then return end
        if GetScreenblurFadeCurrentTime() > 0 then return end
        SetNuiFocus(true, true)
        SetCursorLocation(0.5, 0.5)
        TriggerScreenblurFadeIn(500)
        SendNUIMessage({ action = "showMenu" })
        SetDropData()
        local NewInventory, MaxWeight, MaxSlots, PlayerData = vSERVER.requestInventory()
        if not NewInventory then return errorSound() end
        CurrentInventory = NewInventory
        SendNUIMessage({
            action = "setPlayerInventory",
            payload = {
                inventory = NewInventory,
                maxWeight = math.floor(MaxWeight + 1),
                slots = MaxSlots or 18
            }
        })
        SendNUIMessage({ action = "setPlayerData", payload = PlayerData })
        generateProfilePicture()
    else
        CloseInventory()
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:OPENBUTTON
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterKeyMapping("moc", "Abrir a mochila", "keyboard", "oem_3")
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:SLOT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:Slot")
AddEventHandler("inventory:Slot", function(Number, Amount)
    Usables = parseInt(Number)
    if MumbleIsConnected() then
        vSERVER.UseItem(Number, Amount)
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:USEITEM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("useItem", function(Data, cb)
    if GetGameTimer() >= UseCooldown then
        TriggerEvent("inventory:Slot", Data["slot"], Data["amount"])
        UseCooldown = GetGameTimer() + 1000
    end

    cb("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:UPDATESLOT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("updateSlot", function(Data, cb)
    vRPS.invUpdate(Data["slot"], Data["target"], Data["amount"])
    cb("ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:RETURNWEAPON
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.returnWeapon()
    return CurrentWeapon ~= "" and CurrentWeapon
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXPORT:RETURNWEAPON
-----------------------------------------------------------------------------------------------------------------------------------------
exports("returnWeapon", function()
    return CurrentWeapon ~= "" and CurrentWeapon
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:STOREWEAPON
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.storeWeaponHands()
    if not StoreWeapon then
        StoreWeapon = true

        local Last = CurrentWeapon
        local Ped = PlayerPedId()
        LocalPlayer["state"]:set("Cancel", true, true)

        if not IsPedInAnyVehicle(Ped) then
            if LoadAnim("weapons@pistol@") then
                TaskPlayAnim(Ped, "weapons@pistol@", "aim_2_holster", 8.0, 8.0, -1, 48, 0, 0, 0, 0)
            end

            Wait(450)

            ClearPedTasks(Ped)
        end

        local Ammos = GetAmmoInPedWeapon(Ped, CurrentWeapon)

        StoreWeapon = false
        TriggerEvent("inventory:CleanWeapons", true)
        LocalPlayer["state"]:set("Cancel", false, true)

        return true, Ammos, Last
    end

    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:PUTWEAPONHANDS
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.putWeaponHands(Name, Ammo, Components, Type)
    if LocalPlayer["state"]["SafeZone"] then
        TriggerEvent("Notify", "vermelho", "Você não pode fazer isso aqui.", 5000)
        return
    end

    if not TakeWeapon then
        if not Ammo then
            Ammo = 0
        end

        if Ammo > 0 then
            Actived = true
        end

        TakeWeapon = true
        LocalPlayer["state"]:set("Cancel", true, true)

        local Ped = PlayerPedId()
        if not IsPedInAnyVehicle(Ped) then
            if LoadAnim("rcmjosh4") then
                TaskPlayAnim(Ped, "rcmjosh4", "josh_leadout_cop2", 8.0, 8.0, -1, 48, 0, 0, 0, 0)
            end

            Wait(200)

            CurrentWeapon = Name
            TriggerEvent("inventory:RemoveWeapon", Name)
            GiveWeaponToPed(Ped, Name, Ammo, false, true)

            Wait(300)

            ClearPedTasks(Ped)
        else
            CurrentWeapon = Name
            TriggerEvent("inventory:RemoveWeapon", Name)
            GiveWeaponToPed(Ped, Name, Ammo, false, true)
        end

        if Components then
            for nameItem, _ in pairs(Components) do
                Humble.putAttachs(nameItem, Name)
            end
        end

        if Type then
            Types = Type
        end

        TakeWeapon = false
        LocalPlayer["state"]:set("Cancel", false, true)

        if itemAmmo(Name) then
            TriggerEvent("hud:Weapon", true, Name)
        end

        if not MumbleIsConnected() or vSERVER.dropWeapons(Name) or LocalPlayer["state"]["Safezone"] then
            TriggerEvent("inventory:CleanWeapons", true)
        end

        return true
    end

    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:RECHARGECHECK
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.rechargeCheck(ammoType)
    local weaponAmmo = 0
    local weaponHash = nil
    local Ped = PlayerPedId()
    local weaponStatus = false

    if weaponAmmos[ammoType] then
        weaponAmmo = GetAmmoInPedWeapon(Ped, Weapon)
        for _, v in pairs(weaponAmmos[ammoType]) do
            if CurrentWeapon == v then
                weaponHash = CurrentWeapon
                weaponStatus = true
                break
            end
        end
    end

    return weaponStatus, weaponHash, weaponAmmo
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DROPS:ADICIONAR
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("drops:Adicionar")
AddEventHandler("drops:Adicionar", function(Number, Table)
    Drops[Number] = Table
end)

RegisterNetEvent("drops:Remover")
AddEventHandler("drops:Remover", function(Number)
    if Drops[Number] then
        Drops[Number] = nil
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:DROPBLIPS
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	while true do
		local TimeDistance = 999
		if LocalPlayer["state"]["Route"] < 900000 then
			local Ped = PlayerPedId()
			local Coords = GetEntityCoords(Ped)

			for _,v in pairs(Drops) do
				local Distance = #(Coords - vec3(v["Coords"][1],v["Coords"][2],v["Coords"][3]))
				if Distance <= 50 then
					TimeDistance = 1
					DrawMarker(23,v["Coords"][1],v["Coords"][2],v["Coords"][3] + 0.05,0.0,0.0,0.0,0.0,180.0,0.0,0.15,0.15,0.0,255,255,255,50,0,0,0,0)
					DrawMarker(21,v["Coords"][1],v["Coords"][2],v["Coords"][3] + 0.25,0.0,0.0,0.0,0.0,180.0,0.0,0.20,0.20,0.20,255,0,85,125,0,0,0,1)
				end
			end
		end

		Wait(TimeDistance)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CLEANWEAPONS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:CleanWeapons")
AddEventHandler("inventory:CleanWeapons", function(Create)
    if Weapon ~= "" then
        RemoveAllPedWeapons(PlayerPedId(), true)
    end

    TriggerEvent("hud:Weapon", false)
    Actived = false
    CurrentWeapon = ""
    Types = ""
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRUNKCHEST:OPEN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("trunkchest:Open")
AddEventHandler("trunkchest:Open", function()
    SetNuiFocus(true, true)
    local NewInventory, MaxWeight, MaxSlots = vSERVER.requestInventory()
    if not NewInventory then return errorSound() end
    CurrentInventory = NewInventory
    local myInfos, vehInfos, InventoryWeight, PlayerWeight, ChestWeight, VehicleWeight = vSERVER.openChest()
    CurrentInventory = myInfos
    openTrunkChest(CurrentInventory, MaxWeight, vehInfos, ChestWeight)
    vRP.playAnim(false, { "amb@prop_human_bum_bin@base", "base" }, true)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:OPENTRUNKCHEST
-----------------------------------------------------------------------------------------------------------------------------------------
function openTrunkChest(myInventory, myBackpack, vehInventory, vehWeight)
    trunking = true
    SetNuiFocus(true, true)
    SetCursorLocation(0.5, 0.5)
    TriggerScreenblurFadeIn(500)
    SendNUIMessage({ action = "showMenu" })

    SendNUIMessage({
        action = "setPlayerInventory",
        payload = {
            inventory = myInventory,
            maxWeight = myBackpack
        }
    })
    SendNUIMessage({
        action = "setOtherInventory",
        payload = {
            title = "Mala",
            inventory = vehInventory,
            maxWeight = vehWeight,
            slots = 90
        }
    })
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:TRADEITEM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNuiCallback("tradeItem", function(data, cb)
    if trunking then
        if data.from == "Bolsa" then
            vSERVER.storeTrunkChestItem(data.item.Item, data.slot, data.amount, data.target)
        else
            vSERVER.takeTrunkChestItem(data.item.Item, data.slot, data.amount, data.target)
        end
    elseif data.to == "Chão" then
        print('pegou do chão')
        data.item = data.item.Item
        dropItem(data)
    end
    cb("ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CLEARWEAPONS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:clearWeapons", function()
    local ply = PlayerPedId()
    if CurrentWeapon ~= "" then RemoveAllPedWeapons(ply, true) end
    CurrentWeapon = ""
    Types = ""
    TriggerEvent("utils:PedWeapons", IsPedArmed(ply, 7), GetSelectedPedWeapon(ply))
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:VERIFYWEAPON
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:verifyWeapon")
AddEventHandler("inventory:verifyWeapon",function(Item)
	local Split = splitString(Item,"-")
	local Name = Split[1]

	if Weapon == Name then
		local Ped = PlayerPedId()
		local Ammo = GetAmmoInPedWeapon(Ped,Weapon)
		if not vSERVER.verifyWeapon(Weapon,Ammo) then
			TriggerEvent("inventory:CleanWeapons",false)
		end
	else
		if Weapon == "" then
			vSERVER.verifyWeapon(Name)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:PREVENTWEAPON
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:preventWeapon", function(storeWeapons)
    if CurrentWeapon ~= WEAPON_UNARMED then
        local ply = PlayerPedId()
        local weaponAmmo = GetAmmoInPedWeapon(ply, CurrentWeapon)
        vSERVER.PreventWeapons(CurrentWeapon, weaponAmmo)
        if storeWeapons then RemoveAllPedWeapons(ply, true) end
        CurrentWeapon = ""
        Types = ""
        TriggerEvent("utils:PedWeapons", IsPedArmed(ply, 7), GetSelectedPedWeapon(ply))
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CLOSEINVENTORY
-----------------------------------------------------------------------------------------------------------------------------------------
function CloseInventory()
    while IsScreenblurFadeRunning() do Wait(25) end
    SetNuiFocus(false, false)
    SetCursorLocation(0.5, 0.5)
    SendNUIMessage({ action = "hideMenu" })
    if chestOpen or chestId then
        chestId = nil
        chestOpen = false
    end
    if inspecting then
        inspecting = false
        vSERVER.resetInspect()
    end
    if trunking then
        trunking = false
        vSERVER.trunkChestClose()
        vRP.removeObjects()
    end
    if housing then
        housing = false
        houseName = nil
        houseVault = nil
    end
    TriggerScreenblurFadeOut(500.0)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:DROPITEM
-----------------------------------------------------------------------------------------------------------------------------------------
local function dropItem(data)
    if IsPedInAnyVehicle(ply) then return end
    local coords = GetEntityCoords(ply)
    local gridZone = getGridzone(coords["x"], coords["y"])
    local _, cdz = GetGroundZFor_3dCoord(coords["x"], coords["y"], coords["z"])
    vSERVER.Drops(data["item"], data["slot"], data["amount"], coords["x"], coords["y"], cdz, gridZone)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:PICKUPITEM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("pickupItem", function(data, cb)
    local coords = GetEntityCoords(ply)
    local gridZone = getGridzone(coords["x"], coords["y"])
    vSERVER.Pickup(data["id"], data["amount"], data["target"], gridZone)
    cb("ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:GRIDCHUNK
-----------------------------------------------------------------------------------------------------------------------------------------
function gridChunk(x)
    return math.floor((x + 8192) / 128)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:TOCHANNEL
-----------------------------------------------------------------------------------------------------------------------------------------
function toChannel(v)
    return (v["x"] << 8) | v["y"]
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:BLOCKBUTTONS
-----------------------------------------------------------------------------------------------------------------------------------------
local function BlockButtons()
    while blockButtons do
        DisableControlAction(1, 75, true)
        DisableControlAction(1, 47, true)
        DisableControlAction(1, 257, true)
        DisablePlayerFiring(128, true)
        Wait(0)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:BLOCKINVENTS
-----------------------------------------------------------------------------------------------------------------------------------------
local function blockInvents()
    if exports["player"]:handCuff() then return false end
    return blockButtons
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTS:BLOCKINVENTS
-----------------------------------------------------------------------------------------------------------------------------------------
exports("blockInvents", blockInvents)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:PREVENTWEAPON
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:preventWeapon")
AddEventHandler("inventory:preventWeapon",function()
	if Weapon ~= "" then
		local Ped = PlayerPedId()
		local Ammo = GetAmmoInPedWeapon(Ped,Weapon)

		TriggerEvent("inventory:CreateWeapon",Weapon)
		vSERVER.preventWeapon(Weapon,Ammo)
		TriggerEvent("hud:Weapon",false)
		RemoveAllPedWeapons(Ped,true)
		TriggerEvent("Weapon","")

		Actived = false
		Weapon = ""
		Types = ""
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:APPLYBARBERSHOP
-----------------------------------------------------------------------------------------------------------------------------------------
local function ApplyBarbershopToPed(ped, custom)
    local weightFace = custom[2] / 100 + 0.0
    local weightSkin = custom[4] / 100 + 0.0
    SetPedHeadBlendData(ped, custom[41], custom[1], 0, custom[41], custom[1], 0, weightFace, weightSkin, 0.0, false)
    SetPedEyeColor(ped, custom[3])
    if custom[5] == 0 then
        SetPedHeadOverlay(ped, 0, custom[5], 0.0)
    else
        SetPedHeadOverlay(ped, 0, custom[5], 1.0)
    end
    SetPedHeadOverlay(ped, 6, custom[6], 1.0)
    if custom[7] == 0 then
        SetPedHeadOverlay(ped, 9, custom[7], 0.0)
    else
        SetPedHeadOverlay(ped, 9, custom[7], 1.0)
    end
    SetPedHeadOverlay(ped, 3, custom[8], 1.0)
    SetPedComponentVariation(ped, 2, custom[9], 0, 1)
    SetPedHairColor(ped, custom[10], custom[11])
    SetPedHeadOverlay(ped, 4, custom[12], custom[13] * 0.1)
    SetPedHeadOverlayColor(ped, 4, 1, custom[14], custom[14])
    SetPedHeadOverlay(ped, 8, custom[15], custom[16] * 0.1)
    SetPedHeadOverlayColor(ped, 8, 1, custom[17], custom[17])
    SetPedHeadOverlay(ped, 2, custom[18], custom[19] * 0.1)
    SetPedHeadOverlayColor(ped, 2, 1, custom[20], custom[20])
    SetPedHeadOverlay(ped, 1, custom[21], custom[22] * 0.1)
    SetPedHeadOverlayColor(ped, 1, 1, custom[23], custom[23])
    SetPedHeadOverlay(ped, 5, custom[24], custom[25] * 0.1)
    SetPedHeadOverlayColor(ped, 5, 1, custom[26], custom[26])
    SetPedFaceFeature(ped, 0, custom[27] * 0.1)
    SetPedFaceFeature(ped, 1, custom[28] * 0.1)
    SetPedFaceFeature(ped, 4, custom[29] * 0.1)
    SetPedFaceFeature(ped, 6, custom[30] * 0.1)
    SetPedFaceFeature(ped, 8, custom[31] * 0.1)
    SetPedFaceFeature(ped, 9, custom[32] * 0.1)
    SetPedFaceFeature(ped, 10, custom[33] * 0.1)
    SetPedFaceFeature(ped, 12, custom[34] * 0.1)
    SetPedFaceFeature(ped, 13, custom[35] * 0.1)
    SetPedFaceFeature(ped, 14, custom[36] * 0.1)
    SetPedFaceFeature(ped, 15, custom[37] * 0.1)
    SetPedFaceFeature(ped, 16, custom[38] * 0.1)
    SetPedFaceFeature(ped, 17, custom[39] * 0.1)
    SetPedFaceFeature(ped, 19, custom[40] * 0.1)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:APPLYCLOTHING
-----------------------------------------------------------------------------------------------------------------------------------------
local function ApplyClothingToPed(ped, data, category)
    local item = data.item
    local texture = data.texture
    if category == "pants" then
        SetPedComponentVariation(ped, 4, item, 0, 1)
        SetPedComponentVariation(ped, 4, GetPedDrawableVariation(ped, 4), texture, 1)
    elseif category == "arms" then
        SetPedComponentVariation(ped, 3, item, 0, 1)
        SetPedComponentVariation(ped, 3, GetPedDrawableVariation(ped, 3), texture, 1)
    elseif category == "tshirt" then
        SetPedComponentVariation(ped, 8, item, 0, 1)
        SetPedComponentVariation(ped, 8, GetPedDrawableVariation(ped, 8), texture, 1)
    elseif category == "decals" then
        SetPedComponentVariation(ped, 10, item, 0, 1)
        SetPedComponentVariation(ped, 10, item, texture, 1)
    elseif category == "accessory" then
        SetPedComponentVariation(ped, 7, item, 0, 1)
        SetPedComponentVariation(ped, 7, item, texture, 1)
    elseif category == "torso" then
        SetPedComponentVariation(ped, 11, item, 0, 1)
        SetPedComponentVariation(ped, 11, GetPedDrawableVariation(ped, 11), texture, 1)
    elseif category == "shoes" then
        SetPedComponentVariation(ped, 6, item, 0, 1)
        SetPedComponentVariation(ped, 6, GetPedDrawableVariation(ped, 6), texture, 1)
    elseif category == "mask" then
        SetPedComponentVariation(ped, 1, item, 0, 1)
        SetPedComponentVariation(ped, 1, GetPedDrawableVariation(ped, 1), texture, 1)
    elseif category == "hat" then
        if item ~= -1 then
            SetPedPropIndex(ped, 0, item, texture, 1)
        else
            ClearPedProp(ped, 0)
        end
        SetPedPropIndex(ped, 0, item, texture, 1)
    elseif category == "glass" then
        if item ~= -1 then
            SetPedPropIndex(ped, 1, item, texture, 1)
        else
            ClearPedProp(ped, 1)
        end
        SetPedPropIndex(ped, 1, item, texture, 1)
    elseif category == "ear" then
        if item ~= -1 then
            SetPedPropIndex(ped, 2, item, texture, 1)
        else
            ClearPedProp(ped, 2)
        end
        SetPedPropIndex(ped, 2, item, texture, 1)
    elseif category == "watch" then
        if item ~= -1 then
            SetPedPropIndex(ped, 6, item, texture, 1)
        else
            ClearPedProp(ped, 6)
        end
        SetPedPropIndex(ped, 6, item, texture, 1)
    elseif category == "bracelet" then
        if item ~= -1 then
            SetPedPropIndex(ped, 7, item, texture, 1)
        else
            ClearPedProp(ped, 7)
        end
        SetPedPropIndex(ped, 7, item, texture, 1)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:APPLYTATTOOS
-----------------------------------------------------------------------------------------------------------------------------------------
local function ApplyTattoosToPed(ped, tattoos)
    for index, tatto in pairs(tattoos) do
        SetPedDecoration(ped, joaat(tatto[1]), joaat(index))
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CREATEPED
-----------------------------------------------------------------------------------------------------------------------------------------
local function CreateLocalPed(hash)
    LoadModel(hash)
    local ped = CreatePed(4, hash, GetEntityCoords(ply), false, false)
    while not DoesEntityExist(ped) do Wait(25) end
    return ped
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:DELETEENTITY
-----------------------------------------------------------------------------------------------------------------------------------------
local function DeleteEntityWhileUsingAlpha(entity)
    local alpha = GetEntityAlpha(entity)
    while alpha > 0 do
        alpha -= 1.0
        SetEntityAlpha(entity, alpha, false)
        Wait(0)
    end
    DeleteEntity(entity)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CHAIKIN
-----------------------------------------------------------------------------------------------------------------------------------------
local function chaikin(dest, points, iterations)
    local result = {}
    for i = 1, #points - 1 do
        result[#result + 1] = points[i]
        result[#result + 1] = vec3((points[i].x + points[i + 1].x) / 2, (points[i].y + points[i + 1].y) / 2,
            (points[i].z + points[i + 1].z) / 2)
    end
    result[#result + 1] = points[#points]
    if iterations > 1 then
        chaikin(dest, result, iterations - 1)
    else
        dest.points = result
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:DRAWCURVE
-----------------------------------------------------------------------------------------------------------------------------------------
local function draw_curve(points, particleDict, particleSet, scale, insertionTable)
    insertionTable = {}
    for i = 1, #points - 1 do
        local random_offset_x = math.random(-1, 1)
        local random_offset_y = math.random(-1, 2)
        local random_offset_z = math.random(-1, 2)
        local distance = math.sqrt(random_offset_x * random_offset_x + random_offset_y * random_offset_y)
        random_offset_x /= distance * 2
        random_offset_y /= distance * 2
        UseParticleFxAssetNextCall(particleDict)
        local fx = StartParticleFxLoopedAtCoord(particleSet, points[i].x + random_offset_x, points[i].y + random_offset_y,
            points[i].z + random_offset_z, 0.0, 0.0, 0.0, scale, false, false, false, false)
        table.insert(insertionTable, fx)
    end
    Wait(500)
    for i = 1, #insertionTable do StopParticleFxLooped(insertionTable[i], 0) end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:QUICKFADE
-----------------------------------------------------------------------------------------------------------------------------------------
local function quickFadeIn()
    DoScreenFadeOut(1000)
    Wait(1000)
    DoScreenFadeIn(1000)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:LOADSCALE
-----------------------------------------------------------------------------------------------------------------------------------------
local function LoadScaleform(scaleForm, text)
    local scaleform = RequestScaleformMovie(scaleForm)
    while not HasScaleformMovieLoaded(scaleform) do Wait(0) end
    BeginScaleformMovieMethod(scaleform, "SET_PLAYER_NAME")
    PushScaleformMovieMethodParameterString(text)
    EndScaleformMovieMethod()
    return scaleform
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTS:USEITEM
-----------------------------------------------------------------------------------------------------------------------------------------
exports("useItem", useItem)
RegisterNUICallback("invError", function(_, cb)
    errorSound()
    cb("ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTS:INVCLOSE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("invClose", function(_, cb)
    CloseInventory()
    cb("ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTS:SENDITEM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("sendItem", function(data, cb)
    vSERVER.SendItem(data["slot"], data["amount"])
    cb("ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DELIVER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Deliver",function(Data,Callback)
	vSERVER.Deliver(Data["slot"])

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DESTROYITEM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("destroyItem",function(Data,Callback)
	vSERVER.DestroyItem(Data["slot"],Data["amount"])

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTS:DROPITEM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("dropItem", function(Data, Callback)
    if MumbleIsConnected() and not TakeWeapon and not StoreWeapon then
        local Ped = PlayerPedId()
        local Coords = GetEntityCoords(Ped)
        local _, CoordsZ = GetGroundZFor_3dCoord(Coords["x"], Coords["y"], Coords["z"])

        vSERVER.Drops(Data["item"], Data["slot"], Data["amount"], Coords["x"], Coords["y"], CoordsZ)
    end

    Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:GRIDZONE
-----------------------------------------------------------------------------------------------------------------------------------------
function getGridzone(x, y)
    local gridChunk = vector2(gridChunk(x), gridChunk(y))
    return toChannel(gridChunk)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CLEANWEAPONS:UTILS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:CleanWeapons", function()
    RemoveAllPedWeapons(ply, true)
    useWeapon = ""
    Types = ""
    TriggerEvent("utils:PedWeapons", IsPedArmed(ply, 7), GetSelectedPedWeapon(ply))
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CLOSE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:Close", CloseInventory)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:UPDATE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:Update", function(data)
    local NewInventory, MaxWeight, MaxSlots = vSERVER.requestInventory()
    if not NewInventory then return errorSound() end
    CurrentInventory = NewInventory
    SendNUIMessage({ action = "setPlayerInventory", payload = { inventory = CurrentInventory } })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:UPDATEINV
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.updateInventory(data)
    plyInventory = data
    SendNUIMessage({ action = "setPlayerInventory", payload = { inventory = data } })
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:BLOCKBUTTONS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:blockButtons", function(status)
    blockButtons = status
    if not blockButtons then return end
    CreateThread(BlockButtons)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PARACHUTE
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.Parachute()
	GiveWeaponToPed(PlayerPedId(), "GADGET_PARACHUTE", 1, false, true)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:FIRECRACKER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:Firecracker", function()
    local mHash = "ind_prop_firework_03"
    LoadNamedPtfxAsset("scr_indep_fireworks")
    LoadModel(mHash)
    local explosives = 25
    local fireCrackerDuration = 300000
    fireTimers = GetGameTimer() + fireCrackerDuration
    local coords = GetOffsetFromEntityInWorldCoords(ply, 0.0, 0.6, 0.0)
    firecracker = CreateObject(mHash, coords["x"], coords["y"], coords["z"], true, true, false)
    local netObjs = ObjToNet(firecracker)
    SetNetworkIdCanMigrate(netObjs, true)
    SetEntityAsMissionEntity(firecracker, true, false)
    PlaceObjectOnGroundProperly(firecracker)
    FreezeEntityPosition(firecracker, true)
    Wait(10000)
    repeat
        UseParticleFxAssetNextCall("scr_indep_fireworks")
        StartNetworkedParticleFxNonLoopedAtCoord("scr_indep_firework_trailburst", coords["x"], coords["y"], coords["z"],
            0.0, 0.0, 0.0, 2.5, false, false, false, false)
        explosives = explosives - 1
        Wait(2000)
    until explosives <= 0
    _TRE("tryDeleteObject", netObjs)
    SetTimeout(fireCrackerDuration, function()
        fireTimers = nil
    end)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:APPLYCONDOM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:applyCondom", function()
    local angle = 1.0
    local radius = 0.4
    local lastGameTimer = GetGameTimer()
    local endTimer = lastGameTimer + 60000
    if table.type(scaleForms) == "empty" then
        table.insert(scaleForms,
            {
                scaleform = LoadScaleform("PLAYER_NAME_11", "~y~PROTEGIDO"),
                angleOffset = 0.0,
                rot = vec2(0.0, 0.0),
                posOffset = vec3(0, 0, 0)
            })
        table.insert(scaleForms,
            {
                scaleform = LoadScaleform("PLAYER_NAME_12", "~y~PROTEGIDO "),
                angleOffset = 210.5,
                rot = vec2(0.0, 0.0),
                posOffset = vec3(0, 0, 0)
            })
        table.insert(scaleForms,
            {
                scaleform = LoadScaleform("PLAYER_NAME_13", "~b~PROTEGIDO"),
                angleOffset = 105.25,
                rot = vec2(0.0, 0.0),
                posOffset = vec3(0, 0, 0)
            })
        table.insert(scaleForms,
            {
                scaleform = LoadScaleform("PLAYER_NAME_14", "~b~PROTEGIDO "),
                angleOffset = -105.25,
                rot = vec2(0.0, 0.0),
                posOffset = vec3(0, 0, 0)
            })
    end
    while GetGameTimer() < endTimer do
        local plyCoords = GetEntityCoords(ply)
        for i = 1, 4 do
            local v = scaleForms[i]
            local coords = vec3(plyCoords.x + radius * math.cos(-angle + v.angleOffset),
                plyCoords.y + radius * math.sin(-angle + v.angleOffset), plyCoords.z)
            local heading = GetHeadingFromVector_2d(plyCoords.x - coords.x, plyCoords.y - coords.y)
            DrawScaleformMovie_3dSolid(v.scaleform, coords.x + v.posOffset.x, coords.y + v.posOffset.y,
                coords.z + v.posOffset.z, v.rot.x, v.rot.y, -heading, 1.0, 2.0, 1.0, 2.0, 1.0, 1.0, 1)
        end
        if (GetGameTimer() - lastGameTimer) > 1 then
            angle = angle + 0.02
            lastGameTimer = GetGameTimer()
        end
        Wait(1)
    end
    for i = 1, 4 do
        SetScaleformMovieAsNoLongerNeeded(scaleForms[i].scaleform)
    end
    scaleForms = {}
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:PEDWEAPONS:UTILS
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("utils:PedWeapons", function(armed)
    if not armed then return end
    CreateThread(PreventWeapon)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:VEHICLEPED
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("utils:GetVehiclePedIsIn", function(veh, isDriver)
    if veh == 0 then return DrawDropList() end
    if not isDriver then return end
    if GetEntityModel(veh) ~= -1178021069 then return end
    while plyIsDriver do
        if not IsEntityPlayingAnim(ply, "missfinale_c2leadinoutfin_c_int", "_leadin_loop2_lester", 3) then
            vRP.playAnim(true, { "missfinale_c2leadinoutfin_c_int", "_leadin_loop2_lester" }, true)
        end
        Wait(500)
    end
    vRP.removeObjects("one")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:DROPFUNCTIONS
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.dropFunctions()
    local coords = GetEntityCoords(ply)
    local gridZone = getGridzone(coords["x"], coords["y"])
    local _, cdz = GetGroundZFor_3dCoord(coords["x"], coords["y"], coords["z"])
    return coords["x"], coords["y"], cdz, gridZone
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CHECKFOUNTAIN
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.checkFountain()
    local coords = GetEntityCoords(ply)
    if DoesObjectOfTypeExistAtCoords(coords, 0.7, "prop_watercooler", true) or DoesObjectOfTypeExistAtCoords(coords, 0.7, "prop_watercooler_dark", true) then
        return true, "fountain"
    end
    if IsEntityInWater(ply) then return true, "floor" end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:FISHINGANIM
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.fishingAnim() return IsEntityPlayingAnim(ply, "amb@world_human_stand_fishing@idle_a", "idle_c", 3) end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CHECKWEAPON
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.checkWeapon(Hash)
	if Weapon == Hash then
		return true
	end

	return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- WEAPONATTACHS
-----------------------------------------------------------------------------------------------------------------------------------------
local weaponAttachs = {
	["ATTACH_FLASHLIGHT"] = {
		["WEAPON_PISTOL"] = "COMPONENT_AT_PI_FLSH",
		["WEAPON_PISTOL_MK2"] = "COMPONENT_AT_PI_FLSH_02",
		["WEAPON_APPISTOL"] = "COMPONENT_AT_PI_FLSH",
		["WEAPON_HEAVYPISTOL"] = "COMPONENT_AT_PI_FLSH",
		["WEAPON_MICROSMG"] = "COMPONENT_AT_PI_FLSH",
		["WEAPON_SNSPISTOL_MK2"] = "COMPONENT_AT_PI_FLSH_03",
		["WEAPON_PISTOL50"] = "COMPONENT_AT_PI_FLSH",
		["WEAPON_COMBATPISTOL"] = "COMPONENT_AT_PI_FLSH",
		["WEAPON_CARBINERIFLE"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_CARBINERIFLE_MK2"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_BULLPUPRIFLE"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_BULLPUPRIFLE_MK2"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_SPECIALCARBINE"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_SPECIALCARBINE_MK2"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_PUMPSHOTGUN"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_PUMPSHOTGUN_MK2"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_SMG"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_SMG_MK2"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_ASSAULTRIFLE"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_ASSAULTRIFLE_MK2"] = "COMPONENT_AT_AR_FLSH",
		["WEAPON_ASSAULTSMG"] = "COMPONENT_AT_AR_FLSH"
	},
	["ATTACH_CROSSHAIR"] = {
		["WEAPON_PISTOL_MK2"] = "COMPONENT_AT_PI_RAIL",
		["WEAPON_SNSPISTOL_MK2"] = "COMPONENT_AT_PI_RAIL_02",
		["WEAPON_MICROSMG"] = "COMPONENT_AT_SCOPE_MACRO",
		["WEAPON_CARBINERIFLE"] = "COMPONENT_AT_SCOPE_MEDIUM",
		["WEAPON_CARBINERIFLE_MK2"] = "COMPONENT_AT_SCOPE_MEDIUM_MK2",
		["WEAPON_BULLPUPRIFLE"] = "COMPONENT_AT_SCOPE_SMALL",
		["WEAPON_BULLPUPRIFLE_MK2"] = "COMPONENT_AT_SCOPE_MACRO_02_MK2",
		["WEAPON_SPECIALCARBINE"] = "COMPONENT_AT_SCOPE_MEDIUM",
		["WEAPON_SPECIALCARBINE_MK2"] = "COMPONENT_AT_SCOPE_MEDIUM_MK2",
		["WEAPON_PUMPSHOTGUN_MK2"] = "COMPONENT_AT_SCOPE_SMALL_MK2",
		["WEAPON_SMG"] = "COMPONENT_AT_SCOPE_MACRO_02",
		["WEAPON_SMG_MK2"] = "COMPONENT_AT_SCOPE_SMALL_SMG_MK2",
		["WEAPON_ASSAULTRIFLE"] = "COMPONENT_AT_SCOPE_MACRO",
		["WEAPON_ASSAULTRIFLE_MK2"] = "COMPONENT_AT_SCOPE_MEDIUM_MK2",
		["WEAPON_ASSAULTSMG"] = "COMPONENT_AT_SCOPE_MACRO"
	},
	["ATTACH_MAGAZINE"] = {
		["WEAPON_PISTOL"] = "COMPONENT_PISTOL_CLIP_02",
		["WEAPON_PISTOL_MK2"] = "COMPONENT_PISTOL_MK2_CLIP_02",
		["WEAPON_COMPACTRIFLE"] = "COMPONENT_COMPACTRIFLE_CLIP_02",
		["WEAPON_APPISTOL"] = "COMPONENT_APPISTOL_CLIP_02",
		["WEAPON_HEAVYPISTOL"] = "COMPONENT_HEAVYPISTOL_CLIP_02",
		["WEAPON_MACHINEPISTOL"] = "COMPONENT_MACHINEPISTOL_CLIP_02",
		["WEAPON_MICROSMG"] = "COMPONENT_MICROSMG_CLIP_02",
		["WEAPON_MINISMG"] = "COMPONENT_MINISMG_CLIP_02",
		["WEAPON_SNSPISTOL"] = "COMPONENT_SNSPISTOL_CLIP_02",
		["WEAPON_SNSPISTOL_MK2"] = "COMPONENT_SNSPISTOL_MK2_CLIP_02",
		["WEAPON_VINTAGEPISTOL"] = "COMPONENT_VINTAGEPISTOL_CLIP_02",
		["WEAPON_PISTOL50"] = "COMPONENT_PISTOL50_CLIP_02",
		["WEAPON_COMBATPISTOL"] = "COMPONENT_COMBATPISTOL_CLIP_02",
		["WEAPON_CARBINERIFLE"] = "COMPONENT_CARBINERIFLE_CLIP_02",
		["WEAPON_CARBINERIFLE_MK2"] = "COMPONENT_CARBINERIFLE_MK2_CLIP_02",
		["WEAPON_ADVANCEDRIFLE"] = "COMPONENT_ADVANCEDRIFLE_CLIP_02",
		["WEAPON_BULLPUPRIFLE"] = "COMPONENT_BULLPUPRIFLE_CLIP_02",
		["WEAPON_BULLPUPRIFLE_MK2"] = "COMPONENT_BULLPUPRIFLE_MK2_CLIP_02",
		["WEAPON_SPECIALCARBINE"] = "COMPONENT_SPECIALCARBINE_CLIP_02",
		["WEAPON_SMG"] = "COMPONENT_SMG_CLIP_02",
		["WEAPON_SMG_MK2"] = "COMPONENT_SMG_MK2_CLIP_02",
		["WEAPON_ASSAULTRIFLE"] = "COMPONENT_ASSAULTRIFLE_CLIP_02",
		["WEAPON_ASSAULTRIFLE_MK2"] = "COMPONENT_ASSAULTRIFLE_MK2_CLIP_02",
		["WEAPON_ASSAULTSMG"] = "COMPONENT_ASSAULTSMG_CLIP_02",
		["WEAPON_GUSENBERG"] = "COMPONENT_GUSENBERG_CLIP_02"
	},
	["ATTACH_SILENCER"] = {
		["WEAPON_PISTOL"] = "COMPONENT_AT_PI_SUPP_02",
		["WEAPON_APPISTOL"] = "COMPONENT_AT_PI_SUPP",
		["WEAPON_MACHINEPISTOL"] = "COMPONENT_AT_PI_SUPP",
		["WEAPON_BULLPUPRIFLE"] = "COMPONENT_AT_AR_SUPP",
		["WEAPON_PUMPSHOTGUN_MK2"] = "COMPONENT_AT_SR_SUPP_03",
		["WEAPON_SMG"] = "COMPONENT_AT_PI_SUPP",
		["WEAPON_SMG_MK2"] = "COMPONENT_AT_PI_SUPP",
		["WEAPON_CARBINERIFLE"] = "COMPONENT_AT_AR_SUPP",
		["WEAPON_COLTXM177"] = "COMPONENT_COLTXM177_SUPP",
		["WEAPON_ASSAULTSMG"] = "COMPONENT_AT_AR_SUPP_02"
	},
	["ATTACH_GRIP"] = {
		["WEAPON_CARBINERIFLE"] = "COMPONENT_AT_AR_AFGRIP",
		["WEAPON_CARBINERIFLE_MK2"] = "COMPONENT_AT_AR_AFGRIP_02",
		["WEAPON_BULLPUPRIFLE_MK2"] = "COMPONENT_AT_MUZZLE_01",
		["WEAPON_SPECIALCARBINE"] = "COMPONENT_AT_AR_AFGRIP",
		["WEAPON_SPECIALCARBINE_MK2"] = "COMPONENT_AT_MUZZLE_01",
		["WEAPON_PUMPSHOTGUN_MK2"] = "COMPONENT_AT_MUZZLE_08",
		["WEAPON_SMG_MK2"] = "COMPONENT_AT_MUZZLE_01",
		["WEAPON_ASSAULTRIFLE"] = "COMPONENT_AT_AR_AFGRIP",
		["WEAPON_ASSAULTRIFLE_MK2"] = "COMPONENT_AT_AR_AFGRIP_02"
	},
	["ATTACH_CROSSHAIR2"] = {
		["WEAPON_CARBINERIFLE_MK2"] = "COMPONENT_AT_SCOPE_MACRO_MK2"
	},
	["ATTACH_CROSSHAIR3"] = {
		["WEAPON_CARBINERIFLE_MK2"] = "COMPONENT_AT_SIGHTS"
	},
	["ATTACH_MUZZLE_FAT"] = {
		["WEAPON_PISTOL_MK2"] = "COMPONENT_AT_PI_COMP",
		["WEAPON_CARBINERIFLE_MK2"] = "COMPONENT_AT_MUZZLE_03",
		["WEAPON_SPECIALCARBINE_MK2"] = "COMPONENT_AT_MUZZLE_03",
	    ["WEAPON_BULLPUPRIFLE_MK2"] = "COMPONENT_AT_MUZZLE_03",
		["WEAPON_SMG_MK2"] = "COMPONENT_AT_MUZZLE_03",
		["WEAPON_ASSAULTRIFLE_MK2"] = "COMPONENT_AT_MUZZLE_03"
	},
	["ATTACH_MUZZLE_HEAVY"] = {
		["WEAPON_PISTOL_MK2"] = "COMPONENT_AT_PI_COMP",
		["WEAPON_CARBINERIFLE_MK2"] = "COMPONENT_AT_MUZZLE_05",
	    ["WEAPON_SPECIALCARBINE_MK2"] = "COMPONENT_AT_MUZZLE_05",
		["WEAPON_BULLPUPRIFLE_MK2"] = "COMPONENT_AT_MUZZLE_05",
		["WEAPON_SMG_MK2"] = "COMPONENT_AT_MUZZLE_05",
		["WEAPON_ASSAULTRIFLE_MK2"] = "COMPONENT_AT_MUZZLE_05"
	},
	["ATTACH_BARREL"] = {
		["WEAPON_BULLPUPRIFLE_MK2"] = "COMPONENT_AT_BP_BARREL_02",
		["WEAPON_ASSAULTRIFLE_MK2"] = "COMPONENT_AT_AR_BARREL_02",
		["WEAPON_CARBINERIFLE_MK2"] = "COMPONENT_AT_CR_BARREL_02",
		["WEAPON_SPECIALCARBINE_MK2"] = "COMPONENT_AT_SC_BARREL_02",
		["WEAPON_SMG_MK2"] = "COMPONENT_AT_SB_BARREL_02"
	},
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKATTACHS
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.checkAttachs(nameItem,nameWeapon)
	return weaponAttachs[nameItem][nameWeapon]
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PUTATTACHS
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.putAttachs(nameItem,nameWeapon)
	GiveWeaponComponentToPed(PlayerPedId(),nameWeapon,weaponAttachs[nameItem][nameWeapon])
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:RECHARGEWEAPON
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.rechargeWeapon(weaponHash, ammoAmount)
    local Ped = PlayerPedId()
    AddAmmoToPed(Ped, weaponHash, ammoAmount)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:ADRENALINEDISTANCE
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.adrenalineDistance()
    local coords = GetEntityCoords(ply)
    for i = 1, #adrenalineCds do
        if #(coords - adrenalineCds[i]) < 5 then return true end
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CHECKCRACKER
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.checkCracker() return fireTimers end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CHECKWATER
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.checkWater() return IsPedSwimming(ply) end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CHECKRAGDOLL
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.checkRagdoll() return IsPedRagdoll(ply) end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:WHEELCHAIR
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.wheelChair(vehPlate)
    if plyVeh == 0 then return end
    local heading = GetEntityHeading(ply)
    local coords = GetOffsetFromEntityInWorldCoords(ply, 0.0, 0.75, 0.0)
    local myVehicle = vGARAGE.serverVehicle("wheelchair", coords["x"], coords["y"], coords["z"], heading, vehPlate)
    if not NetworkDoesNetworkIdExist(myVehicle) then return end
    local vehicleNet = NetToEnt(myVehicle)
    if not NetworkDoesNetworkIdExist(vehicleNet) then return end
    SetVehicleOnGroundProperly(vehicleNet)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DOESOBJECTEXIST
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.objectExist(Coords,Hash)
	return DoesObjectOfTypeExistAtCoords(Coords["x"],Coords["y"],Coords["z"],0.35,Hash,true)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:TYREHEALTH
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.tyreHealth(Network,Tyre)
	if NetworkDoesNetworkIdExist(Network) then
		local Vehicle = NetToEnt(Network)
		if DoesEntityExist(Vehicle) then
			return GetTyreHealth(Vehicle,Tyre)
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TYRELIST
-----------------------------------------------------------------------------------------------------------------------------------------
local tyreList = {
	["wheel_lf"] = 0,
	["wheel_rf"] = 1,
	["wheel_lm"] = 2,
	["wheel_rm"] = 3,
	["wheel_lr"] = 4,
	["wheel_rr"] = 5
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:TYRESTATUS
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.tyreStatus()
	local Ped = PlayerPedId()
	if not IsPedInAnyVehicle(Ped) then
		local Vehicle = vRP.ClosestVehicle(7)
		if IsEntityAVehicle(Vehicle) then
			local Coords = GetEntityCoords(Ped)

			for Index,Tyre in pairs(tyreList) do
				local Selected = GetEntityBoneIndexByName(Vehicle,Index)
				if Selected ~= -1 then
					local CoordsWheel = GetWorldPositionOfEntityBone(Vehicle,Selected)
					local Distance = #(Coords - CoordsWheel)
					if Distance <= 1.0 then
						return true,Tyre,VehToNet(Vehicle),GetVehicleNumberPlateText(Vehicle)
					end
				end
			end
		end
	end

	return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:CHECKNEARDOOR
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.checkNearDoor(vehNet)
    if not NetworkDoesEntityExistWithNetworkId(vehNet) then return end
    local veh = NetToVeh(vehNet)
    local doorBone = GetEntityBoneIndexByName(veh, "door_dside_f")
    if doorBone == -1 then return true end
    local doorCds = GetWorldPositionOfEntityBone(veh, doorBone)
    return #(GetEntityCoords(ply) - doorCds) <= 1.5
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:SHORTCUTS
-----------------------------------------------------------------------------------------------------------------------------------------
local function showShortcuts()
    SendNUIMessage({ action = "showHotbar", payload = true })
end
local function hideShortcuts()
    SendNUIMessage({ action = "showHotbar", payload = false })
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- BUTTONS:SHORTCUTS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand("+shortcuts", showShortcuts)
RegisterCommand("-shortcuts", hideShortcuts)
RegisterKeyMapping("+shortcuts", "Visualizar atalhos.", "keyboard", "TAB")
-----------------------------------------------------------------------------------------------------------------------------------------
-- PUTCONDOM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent('putcondom')
AddEventHandler('putcondom', function()
    local angle = 1.0
    local radius = 0.4
    local lastGameTimer = GetGameTimer()
    local ply = PlayerPedId()
    local endTimer = lastGameTimer + 60000
    if table.type(scaleForms) == "empty" then
        table.insert(scaleForms,
            {
                scaleform = LoadScaleform("PLAYER_NAME_11", "~y~PROTEGIDO"),
                angleOffset = 0.0,
                rot = vec2(0.0, 0.0),
                posOffset = vec3(0, 0, 0)
            })
        table.insert(scaleForms,
            {
                scaleform = LoadScaleform("PLAYER_NAME_12", "~y~PROTEGIDO "),
                angleOffset = 210.5,
                rot = vec2(0.0, 0.0),
                posOffset = vec3(0, 0, 0)
            })
        table.insert(scaleForms,
            {
                scaleform = LoadScaleform("PLAYER_NAME_13", "~b~PROTEGIDO"),
                angleOffset = 105.25,
                rot = vec2(0.0, 0.0),
                posOffset = vec3(0, 0, 0)
            })
        table.insert(scaleForms,
            {
                scaleform = LoadScaleform("PLAYER_NAME_14", "~b~PROTEGIDO "),
                angleOffset = -105.25,
                rot = vec2(0.0, 0.0),
                posOffset = vec3(0, 0, 0)
            })
    end
    while GetGameTimer() < endTimer do
        local plyCoords = GetEntityCoords(ply)
        for i = 1, 4 do
            local v = scaleForms[i]
            local coords = vec3(plyCoords.x + radius * math.cos(-angle + v.angleOffset),
                plyCoords.y + radius * math.sin(-angle + v.angleOffset), plyCoords.z)
            local heading = GetHeadingFromVector_2d(plyCoords.x - coords.x, plyCoords.y - coords.y)
            DrawScaleformMovie_3dSolid(v.scaleform, coords.x + v.posOffset.x, coords.y + v.posOffset.y,
                coords.z + v.posOffset.z, v.rot.x, v.rot.y, -heading, 1.0, 2.0, 1.0, 2.0, 1.0, 1.0, 1)
        end
        if (GetGameTimer() - lastGameTimer) > 1 then
            angle = angle + 0.02
            lastGameTimer = GetGameTimer()
        end
        Wait(1)
    end
    for i = 1, 4 do
        SetScaleformMovieAsNoLongerNeeded(scaleForms[i].scaleform)
    end
    scaleForms = {}
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- ATMLIST
-----------------------------------------------------------------------------------------------------------------------------------------
local ATMList = {
	["1"] = { 228.18,338.4,105.56 },
	["2"] = { 158.63,234.22,106.63 },
	["3"] = { -57.67,-92.62,57.78 },
	["4"] = { 356.97,173.54,103.07 },
	["5"] = { -1415.94,-212.03,46.51 },
	["6"] = { -1430.2,-211.08,46.51 },
	["7"] = { -1282.54,-210.9,42.44 },
	["8"] = { -1286.25,-213.44,42.44 },
	["9"] = { -1289.32,-226.82,42.44 },
	["10"] = { -1285.58,-224.28,42.44 },
	["11"] = { -1109.8,-1690.82,4.36 },
	["12"] = { 1686.84,4815.82,42.01 },
	["13"] = { 1701.21,6426.57,32.76 },
	["14"] = { 1822.66,3683.04,34.27 },
	["15"] = { 1171.56,2702.58,38.16 },
	["16"] = { 1172.5,2702.59,38.16 },
	["17"] = { -1091.49,2708.66,18.96 },
	["18"] = { -3144.38,1127.6,20.86 },
	["19"] = { 527.36,-160.69,57.09 },
	["20"] = { 285.45,143.39,104.17 },
	["21"] = { -846.27,-341.28,38.67 },
	["22"] = { -846.85,-340.2,38.67 },
	["23"] = { -721.06,-415.56,34.98 },
	["24"] = { -1410.34,-98.75,52.42 },
	["25"] = { -1409.78,-100.49,52.39 },
	["26"] = { -712.9,-818.92,23.72 },
	["27"] = { -710.05,-818.9,23.72 },
	["28"] = { -660.71,-854.07,24.48 },
	["29"] = { -594.58,-1161.29,22.33 },
	["30"] = { -596.09,-1161.28,22.33 },
	["31"] = { -821.64,-1081.91,11.12 },
	["32"] = { 155.93,6642.86,31.59 },
	["33"] = { 174.14,6637.94,31.58 },
	["34"] = { -283.01,6226.11,31.49 },
	["35"] = { -95.55,6457.19,31.46 },
	["36"] = { -97.3,6455.48,31.46 },
	["37"] = { -132.93,6366.52,31.48 },
	["38"] = { -386.74,6046.08,31.49 },
	["39"] = { 24.47,-945.96,29.35 },
	["40"] = { 5.24,-919.83,29.55 },
	["41"] = { 295.77,-896.1,29.22 },
	["42"] = { 296.47,-894.21,29.23 },
	["43"] = { 1138.22,-468.93,66.73 },
	["44"] = { 1166.97,-456.06,66.79 },
	["45"] = { 1077.75,-776.54,58.23 },
	["46"] = { 289.1,-1256.8,29.44 },
	["47"] = { 288.81,-1282.37,29.64 },
	["48"] = { -1571.05,-547.38,34.95 },
	["49"] = { -1570.12,-546.72,34.95 },
	["50"] = { -1305.4,-706.41,25.33 },
	["51"] = { -2072.36,-317.28,13.31 },
	["52"] = { -2295.48,358.13,174.6 },
	["53"] = { -2294.7,356.46,174.6 },
	["54"] = { -2293.92,354.8,174.6 },
	["55"] = { 2558.75,351.01,108.61 },
	["56"] = { 89.69,2.47,68.29 },
	["57"] = { -866.69,-187.75,37.84 },
	["58"] = { -867.62,-186.09,37.84 },
	["59"] = { -618.22,-708.89,30.04 },
	["60"] = { -618.23,-706.89,30.04 },
	["61"] = { -614.58,-704.83,31.24 },
	["62"] = { -611.93,-704.83,31.24 },
	["63"] = { -537.82,-854.49,29.28 },
	["64"] = { -526.62,-1222.98,18.45 },
	["65"] = { -165.15,232.7,94.91 },
	["66"] = { -165.17,234.78,94.91 },
	["67"] = { -303.25,-829.74,32.42 },
	["68"] = { -301.7,-830.01,32.42 },
	["69"] = { -203.81,-861.37,30.26 },
	["70"] = { 119.06,-883.72,31.12 },
	["71"] = { 112.58,-819.4,31.34 },
	["72"] = { 111.26,-775.25,31.44 },
	["73"] = { 114.43,-776.38,31.41 },
	["74"] = { -256.23,-715.99,33.53 },
	["75"] = { -258.87,-723.38,33.48 },
	["76"] = { -254.42,-692.49,33.6 },
	["77"] = { -28.0,-724.52,44.23 },
	["78"] = { -30.23,-723.69,44.23 },
	["79"] = { -1315.75,-834.69,16.95 },
	["80"] = { -1314.81,-835.96,16.95 },
	["81"] = { -2956.86,487.64,15.47 },
	["82"] = { -2956.89,487.63,15.47 },
	["83"] = { -2958.98,487.73,15.47 },
	["84"] = { -3043.97,594.56,7.73 },
	["85"] = { -3241.17,997.6,12.55 },
	["86"] = { -1205.78,-324.79,37.86 },
	["87"] = { -1205.02,-326.3,37.84 },
	["88"] = { 147.58,-1035.77,29.34 },
	["89"] = { 146.0,-1035.17,29.34 },
	["90"] = { 33.18,-1348.24,29.49 },
	["91"] = { 2558.51,389.48,108.61 },
	["92"] = { 1153.65,-326.78,69.2 },
	["93"] = { -717.71,-915.66,19.21 },
	["94"] = { -56.98,-1752.1,29.42 },
	["95"] = { 380.75,323.39,103.56 },
	["96"] = { -3240.58,1008.59,12.82 },
	["97"] = { 1735.24,6410.52,35.03 },
	["98"] = { 540.31,2671.14,42.16 },
	["99"] = { 1968.07,3743.57,32.33 },
	["100"] = { 2683.1,3286.55,55.23 },
	["101"] = { 1703.0,4933.6,42.06 },
	["102"] = { -1827.3,784.88,138.3 },
	["103"] = { -3040.72,593.11,7.9 },
	["104"] = { 238.32,215.99,106.29 },
	["105"] = { 237.9,216.89,106.29 },
	["106"] = { 237.47,217.81,106.29 },
	["107"] = { 237.04,218.72,106.29 },
	["108"] = { 236.62,219.64,106.29 },
	["109"] = { 126.82,-1296.6,29.27 },
	["110"] = { 127.81,-1296.03,29.27 },
	["111"] = { -248.08,6327.53,32.42 },
	["112"] = { 315.09,-593.68,43.29 },
	["113"] = { 1836.24,3681.04,34.27 },
	["114"] = { -677.36,5834.58,17.32 },
	["115"] = { 472.3,-1001.57,30.68 },
	["116"] = { 468.52,-990.55,26.27 },
	["117"] = { -1431.2,-447.75,35.91 },
	["118"] = { 349.86,-594.51,28.8 },
	["119"] = { -556.12,-205.21,38.22 },
	["120"] = { 560.5,2742.61,42.87 },
	["121"] = { 1099.77,207.12,-49.44 }
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKATM
-----------------------------------------------------------------------------------------------------------------------------------------
function Humble.checkAtm(Coords)
	local BombZone = false
	local AtmSelected = false

	for Number,v in pairs(ATMList) do
		local Distance = #(vec3(Coords["x"],Coords["y"],Coords["z"]) - vec3(v[1],v[2],v[3]))
		if Distance <= 1.0 then
			BombZone = vec3(v[1],v[2],v[3] - 1)
			AtmSelected = Number
			break
		end
	end

	return BombZone,AtmSelected
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADSTART
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	for Number,v in pairs(ATMList) do
		exports["target"]:AddCircleZone("Atm:"..Number,vec3(v[1],v[2],v[3]),0.5,{
			name = "Atm:"..Number,
			heading = 3374176
		},{
			Distance = 1.0,
			options = {
				{
					event = "Bank",
					label = "Abrir",
					tunnel = "client"
				}
			}
		})
	end
end)