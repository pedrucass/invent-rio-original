-----------------------------------------------------------------------------------------------------------------------------------------
-- MEMORY:TASKJEWELRY
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("memory:taskJewelry")
AddEventHandler("memory:taskJewelry",function()
	exports["memory"]:StartMinigame({ success = "inventory:startJewelry", fail = nil })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVENTORY:STARTJEWELRY
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("inventory:startJewelry")
AddEventHandler("inventory:startJewelry",function()
	vSERVER.startJewelry()
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADSTART
-----------------------------------------------------------------------------------------------------------------------------------------
Citizen.CreateThread(function()
	exports["target"]:AddCircleZone("jewelryHacker",vec3(-1048.04,2862.45,8.51),0.75,{
        name = "jewelryHacker",
        heading = 3374176
    },{
        Distance = 0.75,
        options = {
            {
                event = "memory:taskJewelry",
                label = "Hackear",
                tunnel = "client"
            }
        }
    })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADTARGET
-----------------------------------------------------------------------------------------------------------------------------------------
Citizen.CreateThread(function()
	exports["target"]:AddTargetModel({},{
        options = {
            {
                event = "inventory:Showcase",
                label = "Roubar",
                tunnel = "server"
            }
        },
        Distance = 0.75
	})
end)